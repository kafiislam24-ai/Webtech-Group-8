<?php
session_start();
include "dbconnect.php";

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Manager') {
    header("Location: login.php");
    exit();
}

$pending_count = 0;
$active_count = 0;
$resolved_count = 0;

$result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM requests WHERE status = 'Pending'");
if ($result) {
    $row = mysqli_fetch_assoc($result);
    $pending_count = $row['total'];
}

$result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM requests WHERE status IN ('Approved', 'Assigned', 'In Progress', 'Awaiting Parts')");
if ($result) {
    $row = mysqli_fetch_assoc($result);
    $active_count = $row['total'];
}

$result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM requests WHERE status = 'Resolved'");
if ($result) {
    $row = mysqli_fetch_assoc($result);
    $resolved_count = $row['total'];
}

$technicians = [];

$tech_result = mysqli_query(
    $conn,
    "SELECT id, fullname FROM users WHERE role = 'Technician' ORDER BY fullname ASC"
);

if ($tech_result) {
    while ($tech = mysqli_fetch_assoc($tech_result)) {
        $technicians[] = $tech;
    }
}

$sql = "SELECT 
            requests.id,
            requests.user_id,
            requests.equipment_name,
            requests.priority,
            requests.description,
            requests.status,
            requests.created_at,
            users.fullname
        FROM requests
        INNER JOIN users ON requests.user_id = users.id
        ORDER BY requests.created_at DESC";

$request_result = mysqli_query($conn, $sql);

if (!$request_result) {
    die("Request Query Failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EMRS - Manager Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header class="top-nav">
        <h1>EMRS</h1>

        <div class="user-info">
            <span>
                <?php echo htmlspecialchars($_SESSION['user_name']); ?> (Manager)
            </span>

            <a href="logout.php" class="btn-logout">Logout</a>
        </div>
    </header>

    <main class="dashboard-container">

        <section class="metrics-grid">

            <div class="card">
                <h3>Pending Approvals</h3>
                <p class="metric-number">
                    <?php echo $pending_count; ?>
                </p>
            </div>

            <div class="card">
                <h3>Active Maintenance</h3>
                <p class="metric-number">
                    <?php echo $active_count; ?>
                </p>
            </div>

            <div class="card">
                <h3>Total Resolved</h3>
                <p class="metric-number">
                    <?php echo $resolved_count; ?>
                </p>
            </div>

        </section>

        <section class="table-section">

            <div class="dashboard-header">
                <h2>Incoming Equipment Requests</h2>
            </div>

            <table>

                <thead>
                    <tr>
                        <th>Employee and Request</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Assign Technician</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>

                <?php if (mysqli_num_rows($request_result) > 0): ?>

                    <?php while ($request = mysqli_fetch_assoc($request_result)): ?>

                        <tr>

                            <td>
                                <strong>
                                    <?php echo htmlspecialchars($request['fullname']); ?>
                                </strong>
                                -
                                <?php echo htmlspecialchars($request['equipment_name']); ?>
                            </td>

                            <td>
                                <?php
                                echo date(
                                    "M d, Y",
                                    strtotime($request['created_at'])
                                );
                                ?>
                            </td>

                            <td>

                                <?php if ($request['status'] === 'Pending'): ?>

                                    <span class="badge badge-pending">
                                        Pending
                                    </span>

                                <?php elseif (
                                    $request['status'] === 'Assigned' ||
                                    $request['status'] === 'Approved'
                                ): ?>

                                    <span class="badge badge-progress">
                                        <?php echo htmlspecialchars($request['status']); ?>
                                    </span>

                                <?php elseif ($request['status'] === 'In Progress'): ?>

                                    <span class="badge badge-progress">
                                        In Progress
                                    </span>

                                <?php elseif ($request['status'] === 'Resolved'): ?>

                                    <span class="badge badge-resolved">
                                        Resolved
                                    </span>

                                <?php elseif ($request['status'] === 'Rejected'): ?>

                                    <span class="badge badge-pending">
                                        Rejected
                                    </span>

                                <?php else: ?>

                                    <span class="badge">
                                        <?php echo htmlspecialchars($request['status']); ?>
                                    </span>

                                <?php endif; ?>

                            </td>

                            <td>

                                <?php if ($request['status'] === 'Pending'): ?>

                                    <form
                                        id="assignForm<?php echo $request['id']; ?>"
                                        action="form_handler.php"
                                        method="POST"
                                        class="inline-form"
                                    >

                                        <input
                                            type="hidden"
                                            name="action"
                                            value="assign_and_approve"
                                        >

                                        <input
                                            type="hidden"
                                            name="request_id"
                                            value="<?php echo $request['id']; ?>"
                                        >

                                        <select
                                            name="technician_id"
                                            required
                                        >

                                            <option value="">
                                                Select Tech
                                            </option>

                                            <?php foreach ($technicians as $technician): ?>

                                                <option
                                                    value="<?php echo $technician['id']; ?>"
                                                >
                                                    Tech:
                                                    <?php echo htmlspecialchars($technician['fullname']); ?>
                                                </option>

                                            <?php endforeach; ?>

                                        </select>

                                    </form>

                                <?php else: ?>

                                    <span class="text-muted">
                                        No assignment
                                    </span>

                                <?php endif; ?>

                            </td>

                            <td>

                                <?php if ($request['status'] === 'Pending'): ?>

                                    <div class="btn-group">

                                        <button
                                            type="submit"
                                            form="assignForm<?php echo $request['id']; ?>"
                                            name="decision"
                                            value="approve"
                                            class="btn-success btn-sm"
                                        >
                                            Approve
                                        </button>

                                        <form
                                            action="form_handler.php"
                                            method="POST"
                                            class="inline-form"
                                        >

                                            <input
                                                type="hidden"
                                                name="action"
                                                value="reject_request"
                                            >

                                            <input
                                                type="hidden"
                                                name="request_id"
                                                value="<?php echo $request['id']; ?>"
                                            >

                                            <button
                                                type="submit"
                                                class="btn-danger btn-sm"
                                            >
                                                Reject
                                            </button>

                                        </form>

                                    </div>

                                <?php else: ?>

                                    <span class="text-muted">
                                        No Action
                                    </span>

                                <?php endif; ?>

                            </td>

                        </tr>

                    <?php endwhile; ?>

                <?php else: ?>

                    <tr>

                        <td colspan="5" style="text-align:center;">
                            No equipment requests found.
                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </section>

    </main>

</body>
</html>