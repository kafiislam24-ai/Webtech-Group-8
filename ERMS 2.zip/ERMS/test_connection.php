<?php
include "dbconnect.php";

if ($conn) {
    echo "Database connection successful!";
}
?>