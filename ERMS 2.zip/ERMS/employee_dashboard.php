<?php
session_start();
include "dbconnect.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Employee') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$sql = "SELECT COUNT(*) AS total
        FROM requests
        WHERE user_id = ?
        AND status NOT IN ('Resolved', 'Cancelled')";

$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    die("SQL Prepare Failed: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);

$count_result = mysqli_stmt_get_result($stmt);
$count_row = mysqli_fetch_assoc($count_result);
$active_count = $count_row['total'];

mysqli_stmt_close($stmt);


$sql = "SELECT COUNT(*) AS total
        FROM requests
        WHERE user_id = ?
        AND status = 'Resolved'";

$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    die("SQL Prepare Failed: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);

$count_result = mysqli_stmt_get_result($stmt);
$count_row = mysqli_fetch_assoc($count_result);
$resolved_count = $count_row['total'];

mysqli_stmt_close($stmt);


$sql = "SELECT id, equipment_name, priority, description, status, created_at
        FROM requests
        WHERE user_id = ?
        ORDER BY created_at DESC";

$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    die("SQL Prepare Failed: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EMRS - Employee Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header class="top-nav">
        <h1>EMRS</h1>

        <div class="user-info">
            <span>
                <?php echo htmlspecialchars($_SESSION['user_name']); ?> (Employee)
            </span>

            <a href="logout.php" class="btn-logout">Logout</a>
        </div>
    </header>

    <main class="dashboard-container">

        <div class="dashboard-header">
            <h2>My Equipment Requests</h2>

            <a href="request_form.php" class="btn-primary">
                + Submit New Request
            </a>
        </div>

        <section class="metrics-grid">

            <div class="card">
                <h3>Active Requests</h3>
                <p class="metric-number">
                    <?php echo $active_count; ?>
                </p>
            </div>

            <div class="card">
                <h3>Resolved Requests</h3>
                <p class="metric-number">
                    <?php echo $resolved_count; ?>
                </p>
            </div>

        </section>

        <section class="table-section">

            <table>

                <thead>
                    <tr>
                        <th>Request Title</th>
                        <th>Date Submitted</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>

                <?php if (mysqli_num_rows($result) > 0): ?>

                    <?php while ($row = mysqli_fetch_assoc($result)): ?>

                        <tr>

                            <td>
                                <?php echo htmlspecialchars($row['equipment_name']); ?>
                            </td>

                            <td>
                                <?php echo date("M d, Y", strtotime($row['created_at'])); ?>
                            </td>

                            <td>

                                <?php if ($row['status'] === 'Pending'): ?>

                                    <span class="badge badge-pending">
                                        Pending
                                    </span>

                                <?php elseif ($row['status'] === 'Approved'): ?>

                                    <span class="badge badge-progress">
                                        Approved
                                    </span>

                                <?php elseif ($row['status'] === 'Assigned'): ?>

                                    <span class="badge badge-progress">
                                        Assigned
                                    </span>

                                <?php elseif ($row['status'] === 'In Progress'): ?>

                                    <span class="badge badge-progress">
                                        In Progress
                                    </span>

                                <?php elseif ($row['status'] === 'Awaiting Parts'): ?>

                                    <span class="badge badge-progress">
                                        Awaiting Parts
                                    </span>

                                <?php elseif ($row['status'] === 'Resolved'): ?>

                                    <span class="badge badge-resolved">
                                        Resolved
                                    </span>

                                <?php elseif ($row['status'] === 'Cancelled'): ?>

                                    <span class="badge badge-pending">
                                        Cancelled
                                    </span>

                                <?php elseif ($row['status'] === 'Rejected'): ?>

                                    <span class="badge badge-pending">
                                        Rejected
                                    </span>

                                <?php else: ?>

                                    <span class="badge">
                                        <?php echo htmlspecialchars($row['status']); ?>
                                    </span>

                                <?php endif; ?>

                            </td>

                            <td>

                                <?php if ($row['status'] === 'Pending'): ?>

                                    <form action="form_handler.php"
                                          method="POST"
                                          class="inline-form">

                                        <input type="hidden"
                                               name="action"
                                               value="cancel_request">

                                        <input type="hidden"
                                               name="request_id"
                                               value="<?php echo $row['id']; ?>">

                                        <button type="submit"
                                                class="btn-danger btn-sm">
                                            Cancel
                                        </button>

                                    </form>

                                <?php elseif ($row['status'] === 'Resolved'): ?>

                                    <span class="text-muted">
                                        Completed
                                    </span>

                                <?php elseif ($row['status'] === 'Cancelled'): ?>

                                    <span class="text-muted">
                                        Cancelled
                                    </span>

                                <?php elseif ($row['status'] === 'Rejected'): ?>

                                    <span class="text-muted">
                                        Rejected
                                    </span>

                                <?php else: ?>

                                    <span class="text-muted">
                                        No Action
                                    </span>

                                <?php endif; ?>

                            </td>

                        </tr>

                    <?php endwhile; ?>

                <?php else: ?>

                    <tr>
                        <td colspan="4" style="text-align:center;">
                            No requests found.
                        </td>
                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </section>

    </main>

</body>
</html>

<?php
mysqli_stmt_close($stmt);
?>