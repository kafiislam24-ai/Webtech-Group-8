<?php
session_start();
include "dbconnect.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Technician') {
    header("Location: login.php");
    exit();
}

$technician_id = $_SESSION['user_id'];

$assigned_count = 0;
$progress_count = 0;
$completed_count = 0;


$sql = "SELECT COUNT(*) AS total
        FROM requests
        WHERE technician_id = ?
        AND status = 'Assigned'";

$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    die("SQL Prepare Failed: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "i", $technician_id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($result);

$assigned_count = $row['total'];

mysqli_stmt_close($stmt);


$sql = "SELECT COUNT(*) AS total
        FROM requests
        WHERE technician_id = ?
        AND status IN ('In Progress', 'Awaiting Parts')";

$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    die("SQL Prepare Failed: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "i", $technician_id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($result);

$progress_count = $row['total'];

mysqli_stmt_close($stmt);


$sql = "SELECT COUNT(*) AS total
        FROM requests
        WHERE technician_id = ?
        AND status = 'Resolved'
        AND DATE(created_at) = CURDATE()";

$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    die("SQL Prepare Failed: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "i", $technician_id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($result);

$completed_count = $row['total'];

mysqli_stmt_close($stmt);


$sql = "SELECT
            requests.id,
            requests.equipment_name,
            requests.priority,
            requests.description,
            requests.status,
            requests.created_at,
            users.fullname
        FROM requests
        INNER JOIN users
            ON requests.user_id = users.id
        WHERE requests.technician_id = ?
        ORDER BY requests.created_at DESC";

$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    die("SQL Prepare Failed: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "i", $technician_id);
mysqli_stmt_execute($stmt);

$request_result = mysqli_stmt_get_result($stmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EMRS - Technician Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<header class="top-nav">

    <h1>EMRS</h1>

    <div class="user-info">

        <span>
            <?php echo htmlspecialchars($_SESSION['user_name']); ?>
            (Technician)
        </span>

        <a href="logout.php" class="btn-logout">
            Logout
        </a>

    </div>

</header>

<main class="dashboard-container">

    <section class="metrics-grid">

        <div class="card">
            <h3>Assigned Tasks</h3>
            <p class="metric-number">
                <?php echo $assigned_count; ?>
            </p>
        </div>

        <div class="card">
            <h3>In Progress</h3>
            <p class="metric-number">
                <?php echo $progress_count; ?>
            </p>
        </div>

        <div class="card">
            <h3>Completed Today</h3>
            <p class="metric-number">
                <?php echo $completed_count; ?>
            </p>
        </div>

    </section>

    <section class="table-section">

        <div class="dashboard-header">
            <h2>My Assigned Work Queue</h2>
        </div>

        <table>

            <thead>

                <tr>
                    <th>Employee & Equipment</th>
                    <th>Priority</th>
                    <th>Description</th>
                    <th>Work Status</th>
                    <th>Action</th>
                </tr>

            </thead>

            <tbody>

            <?php if (mysqli_num_rows($request_result) > 0): ?>

                <?php while ($request = mysqli_fetch_assoc($request_result)): ?>

                    <tr>

                        <td>
                            <strong>
                                <?php echo htmlspecialchars($request['fullname']); ?>
                            </strong>
                            -
                            <?php echo htmlspecialchars($request['equipment_name']); ?>
                        </td>

                        <td>
                            <?php echo htmlspecialchars($request['priority']); ?>
                        </td>

                        <td>
                            <?php echo htmlspecialchars($request['description']); ?>
                        </td>

                        <td>

                            <?php if ($request['status'] === 'Assigned'): ?>

                                <span class="badge badge-pending">
                                    Assigned
                                </span>

                            <?php elseif ($request['status'] === 'In Progress'): ?>

                                <span class="badge badge-progress">
                                    In Progress
                                </span>

                            <?php elseif ($request['status'] === 'Awaiting Parts'): ?>

                                <span class="badge badge-progress">
                                    Awaiting Parts
                                </span>

                            <?php elseif ($request['status'] === 'Resolved'): ?>

                                <span class="badge badge-resolved">
                                    Resolved
                                </span>

                            <?php else: ?>

                                <span class="badge">
                                    <?php echo htmlspecialchars($request['status']); ?>
                                </span>

                            <?php endif; ?>

                        </td>

                        <td>

                            <?php if ($request['status'] === 'Assigned'): ?>

                                <form
                                    action="form_handler.php"
                                    method="POST"
                                    class="inline-form"
                                >

                                    <input
                                        type="hidden"
                                        name="action"
                                        value="start_task"
                                    >

                                    <input
                                        type="hidden"
                                        name="task_id"
                                        value="<?php echo $request['id']; ?>"
                                    >

                                    <button
                                        type="submit"
                                        class="btn-info btn-sm"
                                    >
                                        Start Work
                                    </button>

                                </form>

                            <?php elseif (
                                $request['status'] === 'In Progress' ||
                                $request['status'] === 'Awaiting Parts'
                            ): ?>

                                <form
                                    action="form_handler.php"
                                    method="POST"
                                    class="inline-form"
                                >

                                    <input
                                        type="hidden"
                                        name="action"
                                        value="update_task"
                                    >

                                    <input
                                        type="hidden"
                                        name="task_id"
                                        value="<?php echo $request['id']; ?>"
                                    >

                                    <select name="work_status" required>

                                        <option value="">
                                            Select Status
                                        </option>

                                        <option value="In Progress">
                                            In Progress
                                        </option>

                                        <option value="Awaiting Parts">
                                            Awaiting Parts
                                        </option>

                                        <option value="Resolved">
                                            Resolved
                                        </option>

                                    </select>

                                    <button
                                        type="submit"
                                        class="btn-success btn-sm"
                                    >
                                        Update
                                    </button>

                                </form>

                            <?php elseif ($request['status'] === 'Resolved'): ?>

                                <span class="text-muted">
                                    Completed
                                </span>

                            <?php else: ?>

                                <span class="text-muted">
                                    No Action
                                </span>

                            <?php endif; ?>

                        </td>

                    </tr>

                <?php endwhile; ?>

            <?php else: ?>

                <tr>

                    <td colspan="5" style="text-align:center;">
                        No assigned requests found.
                    </td>

                </tr>

            <?php endif; ?>

            </tbody>

        </table>

    </section>

</main>

</body>
</html>

<?php
mysqli_stmt_close($stmt);
?>