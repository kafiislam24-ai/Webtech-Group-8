<?php
session_start();
include "dbconnect.php";

function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $action = isset($_POST['action']) ? sanitize_input($_POST['action']) : '';
    $errors = [];

    if ($action === 'login') {

        $email = sanitize_input($_POST['email'] ?? '');
        $password = trim($_POST['password'] ?? '');
        $role = sanitize_input($_POST['role'] ?? '');

        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "A valid email address is required.";
        }

        if (empty($password) || strlen($password) < 6) {
            $errors[] = "Password must be at least 6 characters.";
        }

        $validRoles = ['Employee', 'Manager', 'Technician'];

        if (empty($role) || !in_array($role, $validRoles)) {
            $errors[] = "Please select a valid user role.";
        }

        if (!empty($errors)) {

            echo "<h3>Login Failed:</h3><ul>";

            foreach ($errors as $error) {
                echo "<li style='color:red;'>$error</li>";
            }

            echo "</ul>";
            echo "<a href='login.php'>Go Back</a>";

            exit();
        }

        $sql = "SELECT id, fullname, password, role
                FROM users
                WHERE email = ? AND role = ?";

        $stmt = mysqli_prepare($conn, $sql);

        if (!$stmt) {
            die("SQL Prepare Failed: " . mysqli_error($conn));
        }

        mysqli_stmt_bind_param(
            $stmt,
            "ss",
            $email,
            $role
        );

        mysqli_stmt_execute($stmt);

        mysqli_stmt_bind_result(
            $stmt,
            $user_id,
            $user_name,
            $user_password,
            $user_role
        );

        if (mysqli_stmt_fetch($stmt)) {

            if (password_verify($password, $user_password)) {

                $_SESSION['user_id'] = $user_id;
                $_SESSION['user_name'] = $user_name;
                $_SESSION['role'] = $user_role;

                if (isset($_POST['remember_me'])) {

                    setcookie(
                        'user_email',
                        $email,
                        time() + (86400 * 7),
                        "/"
                    );

                } else {

                    if (isset($_COOKIE['user_email'])) {

                        setcookie(
                            'user_email',
                            '',
                            time() - 3600,
                            "/"
                        );
                    }
                }

                mysqli_stmt_close($stmt);

                if ($user_role === 'Employee') {

                    header("Location: employee_dashboard.php");

                } elseif ($user_role === 'Manager') {

                    header("Location: manager_dashboard.php");

                } elseif ($user_role === 'Technician') {

                    header("Location: technician_dashboard.php");
                }

                exit();

            } else {

                mysqli_stmt_close($stmt);

                echo "<h3 style='color:red;'>Login Failed</h3>";
                echo "<p>Incorrect password.</p>";
                echo "<a href='login.php'>Go Back</a>";

                exit();
            }

        } else {

            mysqli_stmt_close($stmt);

            echo "<h3 style='color:red;'>Login Failed</h3>";
            echo "<p>Email or role does not match any registered account.</p>";
            echo "<a href='login.php'>Go Back</a>";

            exit();
        }

    } elseif ($action === 'register') {

        $fullname = sanitize_input($_POST['fullname'] ?? '');
        $email = sanitize_input($_POST['email'] ?? '');
        $password = trim($_POST['password'] ?? '');
        $confirm_password = trim($_POST['confirm_password'] ?? '');
        $role = sanitize_input($_POST['role'] ?? '');

        if (empty($fullname) || strlen($fullname) < 3) {
            $errors[] = "Full Name must be at least 3 characters.";
        }

        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "A valid email address is required.";
        }

        if (empty($password) || strlen($password) < 6) {
            $errors[] = "Password must be at least 6 characters.";
        }

        if ($password !== $confirm_password) {
            $errors[] = "Passwords do not match.";
        }

        $validRoles = ['Employee', 'Manager', 'Technician'];

        if (empty($role) || !in_array($role, $validRoles)) {
            $errors[] = "Please select a valid role.";
        }

        if (!empty($errors)) {

            echo "<h3>Registration Failed:</h3><ul>";

            foreach ($errors as $error) {
                echo "<li style='color:red;'>$error</li>";
            }

            echo "</ul>";
            echo "<a href='register.php'>Go Back</a>";

            exit();
        }

        $password_hash = password_hash(
            $password,
            PASSWORD_DEFAULT
        );

        $sql = "INSERT INTO users
                (fullname, email, password, role)
                VALUES (?, ?, ?, ?)";

        $stmt = mysqli_prepare($conn, $sql);

        if (!$stmt) {
            die("SQL Prepare Failed: " . mysqli_error($conn));
        }

        mysqli_stmt_bind_param(
            $stmt,
            "ssss",
            $fullname,
            $email,
            $password_hash,
            $role
        );

        if (mysqli_stmt_execute($stmt)) {

            echo "<p style='color:green;'>";
            echo "Registration successful! You may now login.";
            echo "</p>";

            echo "<a href='login.php'>Proceed to Login</a>";

        } else {

            if (mysqli_errno($conn) === 1062) {

                echo "<p style='color:red;'>";
                echo "This email is already registered.";
                echo "</p>";

                echo "<a href='register.php'>Go Back</a>";

            } else {

                echo "<p style='color:red;'>";
                echo "Registration failed: " . mysqli_error($conn);
                echo "</p>";

                echo "<a href='register.php'>Go Back</a>";
            }
        }

        mysqli_stmt_close($stmt);

        exit();
    }
}
?>