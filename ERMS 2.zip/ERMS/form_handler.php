<?php
session_start();
include "dbconnect.php";

function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: login.php");
    exit();
}

$action = isset($_POST['action']) ? sanitize_input($_POST['action']) : '';



/* =========================
   CREATE REQUEST
   ========================= */

if ($action === 'create_request') {

    if ($_SESSION['role'] !== 'Employee') {
        header("Location: login.php");
        exit();
    }

    $user_id = $_SESSION['user_id'];

    $equipment_name = sanitize_input(
        $_POST['equipment_name'] ?? ''
    );

    $priority = sanitize_input(
        $_POST['priority'] ?? ''
    );

    $description = sanitize_input(
        $_POST['description'] ?? ''
    );

    $errors = [];

    if (empty($equipment_name)) {
        $errors[] = "Equipment Name cannot be empty.";
    } elseif (strlen($equipment_name) < 2) {
        $errors[] = "Equipment Name is too short.";
    }

    $validPriorities = ['Low', 'Medium', 'High'];

    if (
        empty($priority) ||
        !in_array($priority, $validPriorities)
    ) {
        $errors[] = "Please select a valid priority level.";
    }

    if (empty($description)) {
        $errors[] = "Issue description is required.";
    } elseif (strlen($description) < 10) {
        $errors[] = "Description must be at least 10 characters long.";
    }

    if (!empty($errors)) {

        echo "<h3>Submission Failed:</h3><ul>";

        foreach ($errors as $error) {
            echo "<li style='color:red;'>$error</li>";
        }

        echo "</ul>";
        echo "<a href='request_form.php'>Go Back to Form</a>";

        exit();
    }

    $sql = "INSERT INTO requests
            (user_id, equipment_name, priority, description, status)
            VALUES (?, ?, ?, ?, 'Pending')";

    $stmt = mysqli_prepare($conn, $sql);

    if (!$stmt) {
        die(
            "SQL Prepare Failed: " .
            mysqli_error($conn)
        );
    }

    mysqli_stmt_bind_param(
        $stmt,
        "isss",
        $user_id,
        $equipment_name,
        $priority,
        $description
    );

    if (mysqli_stmt_execute($stmt)) {

        mysqli_stmt_close($stmt);

        echo "<p style='color:green;'>Request submitted successfully!</p>";
        echo "<a href='employee_dashboard.php'>Back to Dashboard</a>";

    } else {

        echo "<p style='color:red;'>Request submission failed: "
            . mysqli_error($conn)
            . "</p>";

        echo "<a href='request_form.php'>Go Back</a>";

        mysqli_stmt_close($stmt);
    }

    exit();
}



/* =========================
   CANCEL REQUEST
   ========================= */

elseif ($action === 'cancel_request') {

    if ($_SESSION['role'] !== 'Employee') {
        header("Location: login.php");
        exit();
    }

    $user_id = $_SESSION['user_id'];

    $request_id = intval(
        $_POST['request_id'] ?? 0
    );

    if ($request_id <= 0) {

        echo "<p style='color:red;'>Invalid request ID.</p>";
        echo "<a href='employee_dashboard.php'>Back to Dashboard</a>";

        exit();
    }

    $sql = "UPDATE requests
            SET status = 'Cancelled'
            WHERE id = ?
            AND user_id = ?
            AND status = 'Pending'";

    $stmt = mysqli_prepare($conn, $sql);

    if (!$stmt) {
        die(
            "SQL Prepare Failed: " .
            mysqli_error($conn)
        );
    }

    mysqli_stmt_bind_param(
        $stmt,
        "ii",
        $request_id,
        $user_id
    );

    if (mysqli_stmt_execute($stmt)) {

        if (mysqli_stmt_affected_rows($stmt) > 0) {

            mysqli_stmt_close($stmt);

            header("Location: employee_dashboard.php");
            exit();

        } else {

            mysqli_stmt_close($stmt);

            echo "<p style='color:red;'>Request could not be cancelled.</p>";
            echo "<p>The request may already be cancelled or is no longer pending.</p>";
            echo "<a href='employee_dashboard.php'>Back to Dashboard</a>";

            exit();
        }

    } else {

        echo "<p style='color:red;'>Cancel request failed: "
            . mysqli_error($conn)
            . "</p>";

        echo "<a href='employee_dashboard.php'>Back to Dashboard</a>";

        mysqli_stmt_close($stmt);

        exit();
    }
}



/* =========================
   ASSIGN TECHNICIAN
   ========================= */

elseif ($action === 'assign_and_approve') {

    if ($_SESSION['role'] !== 'Manager') {
        header("Location: login.php");
        exit();
    }

    $request_id = intval(
        $_POST['request_id'] ?? 0
    );

    $technician_id = intval(
        $_POST['technician_id'] ?? 0
    );

    if (
        $request_id <= 0 ||
        $technician_id <= 0
    ) {

        echo "<p style='color:red;'>Please select a valid technician.</p>";
        echo "<a href='manager_dashboard.php'>Back to Dashboard</a>";

        exit();
    }

    $check_sql = "SELECT id
                  FROM users
                  WHERE id = ?
                  AND role = 'Technician'";

    $check_stmt = mysqli_prepare(
        $conn,
        $check_sql
    );

    if (!$check_stmt) {
        die(
            "SQL Prepare Failed: " .
            mysqli_error($conn)
        );
    }

    mysqli_stmt_bind_param(
        $check_stmt,
        "i",
        $technician_id
    );

    mysqli_stmt_execute($check_stmt);

    mysqli_stmt_store_result(
        $check_stmt
    );

    if (
        mysqli_stmt_num_rows(
            $check_stmt
        ) === 0
    ) {

        mysqli_stmt_close(
            $check_stmt
        );

        echo "<p style='color:red;'>Invalid technician selected.</p>";
        echo "<a href='manager_dashboard.php'>Back to Dashboard</a>";

        exit();
    }

    mysqli_stmt_close(
        $check_stmt
    );

    $sql = "UPDATE requests
            SET technician_id = ?,
                status = 'Assigned'
            WHERE id = ?
            AND status = 'Pending'";

    $stmt = mysqli_prepare(
        $conn,
        $sql
    );

    if (!$stmt) {
        die(
            "SQL Prepare Failed: " .
            mysqli_error($conn)
        );
    }

    mysqli_stmt_bind_param(
        $stmt,
        "ii",
        $technician_id,
        $request_id
    );

    if (
        mysqli_stmt_execute($stmt)
    ) {

        if (
            mysqli_stmt_affected_rows($stmt) > 0
        ) {

            mysqli_stmt_close($stmt);

            header(
                "Location: manager_dashboard.php"
            );

            exit();

        } else {

            mysqli_stmt_close($stmt);

            echo "<p style='color:red;'>Request could not be approved.</p>";
            echo "<p>The request may no longer be pending.</p>";
            echo "<a href='manager_dashboard.php'>Back to Dashboard</a>";

            exit();
        }

    } else {

        echo "<p style='color:red;'>Approval failed: "
            . mysqli_error($conn)
            . "</p>";

        echo "<a href='manager_dashboard.php'>Back to Dashboard</a>";

        mysqli_stmt_close($stmt);

        exit();
    }
}



/* =========================
   REJECT REQUEST
   ========================= */

elseif ($action === 'reject_request') {

    if ($_SESSION['role'] !== 'Manager') {
        header("Location: login.php");
        exit();
    }

    $request_id = intval(
        $_POST['request_id'] ?? 0
    );

    if ($request_id <= 0) {

        echo "<p style='color:red;'>Invalid request ID.</p>";
        echo "<a href='manager_dashboard.php'>Back to Dashboard</a>";

        exit();
    }

    $sql = "UPDATE requests
            SET status = 'Rejected'
            WHERE id = ?
            AND status = 'Pending'";

    $stmt = mysqli_prepare(
        $conn,
        $sql
    );

    if (!$stmt) {
        die(
            "SQL Prepare Failed: " .
            mysqli_error($conn)
        );
    }

    mysqli_stmt_bind_param(
        $stmt,
        "i",
        $request_id
    );

    if (
        mysqli_stmt_execute($stmt)
    ) {

        if (
            mysqli_stmt_affected_rows($stmt) > 0
        ) {

            mysqli_stmt_close($stmt);

            header(
                "Location: manager_dashboard.php"
            );

            exit();

        } else {

            mysqli_stmt_close($stmt);

            echo "<p style='color:red;'>Request could not be rejected.</p>";
            echo "<a href='manager_dashboard.php'>Back to Dashboard</a>";

            exit();
        }

    } else {

        echo "<p style='color:red;'>Reject failed: "
            . mysqli_error($conn)
            . "</p>";

        echo "<a href='manager_dashboard.php'>Back to Dashboard</a>";

        mysqli_stmt_close($stmt);

        exit();
    }
}



/* =========================
   START TASK
   ========================= */

elseif ($action === 'start_task') {

    if ($_SESSION['role'] !== 'Technician') {
        header("Location: login.php");
        exit();
    }

    $technician_id = $_SESSION['user_id'];

    $task_id = intval(
        $_POST['task_id'] ?? 0
    );

    if ($task_id <= 0) {

        echo "<p style='color:red;'>Invalid task ID.</p>";
        echo "<a href='technician_dashboard.php'>Back to Dashboard</a>";

        exit();
    }

    $sql = "UPDATE requests
            SET status = 'In Progress'
            WHERE id = ?
            AND technician_id = ?
            AND status = 'Assigned'";

    $stmt = mysqli_prepare(
        $conn,
        $sql
    );

    if (!$stmt) {
        die(
            "SQL Prepare Failed: " .
            mysqli_error($conn)
        );
    }

    mysqli_stmt_bind_param(
        $stmt,
        "ii",
        $task_id,
        $technician_id
    );

    if (
        mysqli_stmt_execute($stmt)
    ) {

        if (
            mysqli_stmt_affected_rows($stmt) > 0
        ) {

            mysqli_stmt_close($stmt);

            header(
                "Location: technician_dashboard.php"
            );

            exit();

        } else {

            mysqli_stmt_close($stmt);

            echo "<p style='color:red;'>Task could not be started.</p>";
            echo "<a href='technician_dashboard.php'>Back to Dashboard</a>";

            exit();
        }

    } else {

        echo "<p style='color:red;'>Start task failed: "
            . mysqli_error($conn)
            . "</p>";

        echo "<a href='technician_dashboard.php'>Back to Dashboard</a>";

        mysqli_stmt_close($stmt);

        exit();
    }
}



/* =========================
   UPDATE TECHNICIAN TASK
   ========================= */

elseif ($action === 'update_task') {

    if ($_SESSION['role'] !== 'Technician') {
        header("Location: login.php");
        exit();
    }

    $technician_id = $_SESSION['user_id'];

    $task_id = intval(
        $_POST['task_id'] ?? 0
    );

    $work_status = sanitize_input(
        $_POST['work_status'] ?? ''
    );

    $validStatuses = [
        'In Progress',
        'Awaiting Parts',
        'Resolved'
    ];

    if ($task_id <= 0) {

        echo "<p style='color:red;'>Invalid task ID.</p>";
        echo "<a href='technician_dashboard.php'>Back to Dashboard</a>";

        exit();
    }

    if (!in_array(
        $work_status,
        $validStatuses
    )) {

        echo "<p style='color:red;'>Invalid work status.</p>";
        echo "<a href='technician_dashboard.php'>Back to Dashboard</a>";

        exit();
    }

    $sql = "UPDATE requests
            SET status = ?
            WHERE id = ?
            AND technician_id = ?
            AND status IN ('In Progress', 'Awaiting Parts')";

    $stmt = mysqli_prepare(
        $conn,
        $sql
    );

    if (!$stmt) {
        die(
            "SQL Prepare Failed: " .
            mysqli_error($conn)
        );
    }

    mysqli_stmt_bind_param(
        $stmt,
        "sii",
        $work_status,
        $task_id,
        $technician_id
    );

    if (
        mysqli_stmt_execute($stmt)
    ) {

        if (
            mysqli_stmt_affected_rows($stmt) > 0
        ) {

            mysqli_stmt_close($stmt);

            header(
                "Location: technician_dashboard.php"
            );

            exit();

        } else {

            mysqli_stmt_close($stmt);

            echo "<p style='color:red;'>Task status could not be updated.</p>";
            echo "<a href='technician_dashboard.php'>Back to Dashboard</a>";

            exit();
        }

    } else {

        echo "<p style='color:red;'>Update failed: "
            . mysqli_error($conn)
            . "</p>";

        echo "<a href='technician_dashboard.php'>Back to Dashboard</a>";

        mysqli_stmt_close($stmt);

        exit();
    }
}

else {

    echo "<p style='color:red;'>Invalid action.</p>";
    echo "<a href='login.php'>Go to Login</a>";

    exit();
}
?>